package com.example.shortcuts

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------- Home with tab bar ----------------

@Composable
fun HomeScreen(nav: Nav) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                NavigationBarItem(selected = nav.tab == 0, onClick = { nav.tab = 0 }, colors = colors,
                    icon = { Text("▦", fontSize = 22.sp, color = if (nav.tab == 0) Ios.blue else Ios.gray) },
                    label = { Text("Shortcuts") })
                NavigationBarItem(selected = nav.tab == 1, onClick = { nav.tab = 1 }, colors = colors,
                    icon = { Text("⚙", fontSize = 22.sp, color = if (nav.tab == 1) Ios.blue else Ios.gray) },
                    label = { Text("Automation") })
                NavigationBarItem(selected = nav.tab == 2, onClick = { nav.tab = 2 }, colors = colors,
                    icon = { Text("✦", fontSize = 22.sp, color = if (nav.tab == 2) Ios.blue else Ios.gray) },
                    label = { Text("Gallery") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (nav.tab) {
                0 -> RootLibrary(nav)
                1 -> AutomationTab(nav)
                else -> GalleryTab(nav)
            }
        }
    }
}

private fun readClipboard(ctx: Context): String {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val c = cm.primaryClip
    return if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(ctx).toString() else ""
}

private fun newShortcut(nav: Nav, folderId: String? = null) {
    val s = Shortcut(name = "New Shortcut", color = Store.items.size % TileColors.size, folderId = folderId)
    Store.add(s)
    nav.push(Route.Editor(s.id))
}

// ---------------- Root: folders list ----------------

@Composable
fun RootLibrary(nav: Nav) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                nav.importText(text)
            } catch (e: Exception) {
                nav.toastText = "Could not read that file"
            }
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.weight(1f))
                LinkText("＋") { newShortcut(nav) }
                Box {
                    LinkText("•••") { menu = true }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("New Folder") }, onClick = { menu = false; newFolder = true })
                        DropdownMenuItem(text = { Text("Import from file") }, onClick = { menu = false; picker.launch(arrayOf("*/*")) })
                        DropdownMenuItem(text = { Text("Import from clipboard") }, onClick = { menu = false; nav.importText(readClipboard(ctx)) })
                        DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; nav.push(Route.Settings) })
                    }
                }
            }
            Text("Shortcuts", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Search") },
                leadingIcon = { Text("🔍") },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            )
        }
        if (query.isNotBlank()) {
            val hits = Store.items.filter { it.name.contains(query, true) }
            items(hits, key = { it.id }) { s ->
                Box(Modifier.padding(bottom = 8.dp)) { ShortcutRow(s, nav) }
            }
        } else {
            item {
                Group {
                    FolderRow("🗂️", 6, "All Shortcuts", Store.items.size) { nav.push(Route.Collection("all")) }
                    HorizontalDivider(Modifier.padding(start = 56.dp))
                    FolderRow("📤", 4, "Share Sheet", Store.items.count { it.share }) { nav.push(Route.Collection("share")) }
                }
                if (Store.folders.isNotEmpty()) SectionLabel("Folders")
            }
            if (Store.folders.isNotEmpty()) {
                item {
                    Group {
                        Store.folders.forEachIndexed { idx, f ->
                            if (idx > 0) HorizontalDivider(Modifier.padding(start = 56.dp))
                            FolderRow(f.glyph, f.color, f.name, Store.items.count { it.folderId == f.id }) {
                                nav.push(Route.Collection("folder", f.id))
                            }
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(12.dp))
                LinkText("＋  New Folder") { newFolder = true }
            }
        }
    }

    if (newFolder) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newFolder = false },
            title = { Text("New Folder") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Folder name") }) },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) Store.addFolder(Folder(name = name.trim(), color = Store.folders.size % TileColors.size))
                    newFolder = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { newFolder = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun FolderRow(glyph: String, color: Int, title: String, count: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlyphBox(glyph, tileColor(color), 32.dp, 8.dp)
        Text(title, fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
        Text("$count", color = Ios.gray, fontSize = 17.sp)
        Text("  ›", color = Ios.gray, fontSize = 20.sp)
    }
}

// ---------------- Collection (grid / list) ----------------

@Composable
fun CollectionScreen(nav: Nav, route: Route.Collection) {
    val ctx = LocalContext.current
    var selectMode by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }
    var menu by remember { mutableStateOf(false) }
    var moveDialog by remember { mutableStateOf(false) }
    var renameDialog by remember { mutableStateOf(false) }

    val folder = route.folderId?.let { fid -> Store.folders.firstOrNull { it.id == fid } }
    val title = when (route.kind) {
        "share" -> "Share Sheet"
        "folder" -> folder?.name ?: "Folder"
        else -> "All Shortcuts"
    }
    val base = when (route.kind) {
        "share" -> Store.items.filter { it.share }
        "folder" -> Store.items.filter { it.folderId == route.folderId }
        else -> Store.items.toList()
    }
    val list = Store.sorted(base)

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                val chosen = Store.items.filter { it.id in selected }
                val text = if (chosen.size == 1) Store.exportOne(chosen[0]) else Store.exportAll()
                ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
                nav.toastText = "Exported"
            } catch (e: Exception) {
                nav.toastText = "Export failed"
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            LinkText("‹ Shortcuts") { nav.pop() }
            Spacer(Modifier.weight(1f))
            if (selectMode) {
                LinkText("Done") { selectMode = false; selected.clear() }
            } else {
                LinkText("Select") { selectMode = true }
                LinkText("＋") { newShortcut(nav, if (route.kind == "folder") route.folderId else null) }
                Box {
                    LinkText("•••") { menu = true }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(if (Store.layout == "Grid") "✓ Grid" else "Grid") }, onClick = { menu = false; Store.changeLayout("Grid") })
                        DropdownMenuItem(text = { Text(if (Store.layout == "List") "✓ List" else "List") }, onClick = { menu = false; Store.changeLayout("List") })
                        HorizontalDivider()
                        for (so in listOf("Name", "Last Modified", "Date Created", "Custom Order")) {
                            DropdownMenuItem(text = { Text(if (Store.sort == so) "✓ $so" else so) }, onClick = { menu = false; Store.changeSort(so) })
                        }
                        if (route.kind == "folder") {
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Rename Folder") }, onClick = { menu = false; renameDialog = true })
                            DropdownMenuItem(text = { Text("Delete Folder") }, onClick = {
                                menu = false
                                route.folderId?.let { Store.deleteFolder(it) }
                                nav.pop()
                            })
                        }
                    }
                }
            }
        }
        Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, bottom = 8.dp))

        if (list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No shortcuts here yet.\nTap ＋ or browse the Gallery.", color = Ios.gray)
            }
        } else if (Store.layout == "Grid") {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.id }) { s ->
                    Tile(s, nav, selectMode, s.id in selected) {
                        if (selected.contains(s.id)) selected.remove(s.id) else selected.add(s.id)
                    }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.id }) { s ->
                    ShortcutRow(s, nav, selectMode, s.id in selected) {
                        if (selected.contains(s.id)) selected.remove(s.id) else selected.add(s.id)
                    }
                }
            }
        }

        if (selectMode) {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                LinkText("Delete", Ios.red) {
                    selected.toList().forEach { Store.delete(it) }
                    selected.clear()
                }
                LinkText("Duplicate") { selected.toList().forEach { Store.duplicate(it) }; selected.clear() }
                LinkText("Move") { if (selected.isNotEmpty()) moveDialog = true }
                LinkText("Export") { if (selected.isNotEmpty()) saver.launch("shortcuts.json") }
            }
        }
    }

    if (moveDialog) MoveDialog(selected.toList(), onClose = { moveDialog = false; selected.clear(); selectMode = false })

    if (renameDialog && folder != null) {
        var name by remember { mutableStateOf(folder.name) }
        AlertDialog(
            onDismissRequest = { renameDialog = false },
            title = { Text("Rename Folder") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) Store.renameFolder(folder.id, name.trim()); renameDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renameDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun MoveDialog(ids: List<String>, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Move to Folder") },
        text = {
            Column {
                TextButton(onClick = {
                    ids.forEach { id -> Store.get(id)?.let { Store.update(it.copy(folderId = null)) } }
                    onClose()
                }) { Text("No folder") }
                Store.folders.forEach { f ->
                    TextButton(onClick = {
                        ids.forEach { id -> Store.get(id)?.let { Store.update(it.copy(folderId = f.id)) } }
                        onClose()
                    }) { Text(f.glyph + "  " + f.name) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

// ---------------- Tiles and rows ----------------

@Composable
private fun ShortcutMenu(s: Shortcut, nav: Nav, expanded: Boolean, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var moveDialog by remember { mutableStateOf(false) }
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("Edit") }, onClick = { onDismiss(); nav.push(Route.Editor(s.id)) })
        DropdownMenuItem(text = { Text("Details") }, onClick = { onDismiss(); nav.push(Route.Details(s.id)) })
        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { onDismiss(); Store.duplicate(s.id) })
        DropdownMenuItem(text = { Text("Add to Home Screen") }, onClick = { onDismiss(); Integrations.pin(ctx, s) })
        DropdownMenuItem(text = { Text("Share") }, onClick = {
            onDismiss()
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Store.exportOne(s))
            ctx.startActivity(Intent.createChooser(i, "Share shortcut"))
        })
        DropdownMenuItem(text = { Text("Move to Folder") }, onClick = { onDismiss(); moveDialog = true })
        if (Store.sort == "Custom Order") {
            DropdownMenuItem(text = { Text("Move Earlier") }, onClick = { onDismiss(); Store.move(s.id, -1) })
            DropdownMenuItem(text = { Text("Move Later") }, onClick = { onDismiss(); Store.move(s.id, 1) })
        }
        DropdownMenuItem(text = { Text("Delete", color = Ios.red) }, onClick = { onDismiss(); Store.delete(s.id) })
    }
    if (moveDialog) MoveDialog(listOf(s.id), onClose = { moveDialog = false })
}

@Composable
fun Tile(s: Shortcut, nav: Nav, selectMode: Boolean = false, isSelected: Boolean = false, onToggle: () -> Unit = {}) {
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxWidth().height(100.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(tileColor(s.color))
            .clickable { if (selectMode) onToggle() else nav.run(s) }
            .padding(12.dp)
    ) {
        Text(s.glyph, fontSize = 26.sp, modifier = Modifier.align(Alignment.TopStart))
        if (selectMode) {
            Box(
                Modifier.align(Alignment.TopEnd).size(24.dp).clip(CircleShape)
                    .background(if (isSelected) Color.White else Color.White.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) { if (isSelected) Text("✓", color = Ios.blue, fontWeight = FontWeight.Bold) }
        } else {
            Box(Modifier.align(Alignment.TopEnd)) {
                Box(
                    Modifier.size(26.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f)).clickable { menu = true },
                    contentAlignment = Alignment.Center
                ) { Text("•••", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                ShortcutMenu(s, nav, menu) { menu = false }
            }
        }
        Text(
            s.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart)
        )
    }
}

@Composable
fun ShortcutRow(s: Shortcut, nav: Nav, selectMode: Boolean = false, isSelected: Boolean = false, onToggle: () -> Unit = {}) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable { if (selectMode) onToggle() else nav.run(s) }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlyphBox(s.glyph, tileColor(s.color), 40.dp, 10.dp)
        Text(s.name, fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp).weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (selectMode) {
            Text(if (isSelected) "✅" else "⚪", fontSize = 20.sp)
        } else {
            Text("▶", color = Ios.blue, modifier = Modifier.clickable { nav.run(s) }.padding(8.dp))
            Box {
                Text("•••", color = Ios.gray, modifier = Modifier.clickable { menu = true }.padding(8.dp))
                ShortcutMenu(s, nav, menu) { menu = false }
            }
        }
    }
}
