package com.example.shortcuts

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
private fun TopRow(title: String, nav: Nav, backLabel: String = "‹", trailing: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        LinkText(backLabel) { nav.pop() }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 4.dp))
        trailing()
    }
}

// ---------------- Details ----------------

@Composable
fun DetailsScreen(nav: Nav, id: String) {
    val ctx = LocalContext.current
    val sc = Store.get(id)
    if (sc == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(Store.exportOne(sc)) }
                nav.toastText = "Exported"
            } catch (e: Exception) { nav.toastText = "Export failed" }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopRow("Details", nav, "‹ Done")
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = sc.name, onValueChange = { Store.update(sc.copy(name = it)) },
                label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            SectionLabel("Color")
            Group(Modifier.padding(12.dp)) {
                TileColors.indices.toList().chunked(6).forEach { rowIdx ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        rowIdx.forEach { i ->
                            Box(
                                Modifier.size(if (i == sc.color) 40.dp else 34.dp).clip(CircleShape).background(tileColor(i))
                                    .clickable { Store.update(sc.copy(color = i)) }
                            )
                        }
                    }
                }
            }
            SectionLabel("Icon")
            Group(Modifier.padding(8.dp)) {
                Glyphs.chunked(8).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { g ->
                            Box(
                                Modifier.size(38.dp).clip(RoundedCornerShape(8.dp))
                                    .background(if (g == sc.glyph) tileColor(sc.color) else Color.Transparent)
                                    .clickable { Store.update(sc.copy(glyph = g)) },
                                contentAlignment = Alignment.Center
                            ) { Text(g, fontSize = 20.sp) }
                        }
                    }
                }
            }
            SectionLabel("Show in")
            Group {
                SwitchRow("Share Sheet", sc.share) { Store.update(sc.copy(share = it)) }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                SwitchRow("Quick Settings tile", sc.qs) { Store.update(sc.copy(qs = it)) }
            }
            Text(
                "Quick Settings: add the \"Shortcut 1/2/3\" tiles from the system tile editor. They run the 1st/2nd/3rd shortcut with this switch on.",
                fontSize = 12.sp, color = Ios.gray, modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
            SectionLabel("Actions")
            Group {
                ActionRow("Add to Home Screen") { Integrations.pin(ctx, sc) }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Import Questions") { nav.push(Route.Questions(sc.id)) }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Share Shortcut") {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Store.exportOne(sc))
                    ctx.startActivity(Intent.createChooser(i, "Share shortcut"))
                }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Save as File") { saver.launch(sc.name.replace(" ", "_") + ".json") }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Duplicate") { Store.duplicate(sc.id); nav.toastText = "Duplicated" }
            }
            Spacer(Modifier.height(16.dp))
            Group {
                ActionRow("Delete Shortcut", Ios.red) {
                    Store.delete(sc.id)
                    nav.pop()
                    if (nav.stack.lastOrNull() is Route.Editor) nav.pop()
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 17.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionRow(title: String, color: Color = Ios.blue, onClick: () -> Unit) {
    Text(
        title, color = color, fontSize = 17.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp)
    )
}

// ---------------- Import questions ----------------

@Composable
fun QuestionsScreen(nav: Nav, id: String) {
    val sc = Store.get(id)
    if (sc == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    Column(Modifier.fillMaxSize()) {
        TopRow("Import Questions", nav, "‹ Done")
        Text(
            "When someone imports this shortcut they'll be asked these questions and their answers fill the matching fields. Leave a question empty to skip it.",
            fontSize = 13.sp, color = Ios.gray, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (step in sc.steps) {
                val def = Catalog.byType[step.type] ?: continue
                for (p in def.params) {
                    if (p.options != null) continue
                    item(key = step.id + ":" + p.key) {
                        val current = sc.questions.firstOrNull { it.stepId == step.id && it.key == p.key }?.text ?: ""
                        OutlinedTextField(
                            value = current,
                            onValueChange = { v ->
                                val rest = sc.questions.filterNot { it.stepId == step.id && it.key == p.key }
                                val qs = if (v.isBlank()) rest else rest + ImportQuestion(step.id, p.key, v)
                                Store.update(sc.copy(questions = qs))
                            },
                            label = { Text(def.title + " – " + p.label) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ImportDialog(list: List<Shortcut>, onDone: (Boolean) -> Unit) {
    val answers = remember { mutableStateMapOf<String, String>() }
    fun akey(i: Int, q: ImportQuestion) = "$i:${q.stepId}:${q.key}"
    AlertDialog(
        onDismissRequest = { onDone(false) },
        title = { Text(if (list.size == 1) "Add \"${list[0].name}\"?" else "Add ${list.size} shortcuts?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                list.forEachIndexed { i, s ->
                    Text("${s.glyph} ${s.name} · ${s.steps.size} actions", fontWeight = FontWeight.Medium)
                    s.questions.forEach { q ->
                        val init = s.steps.firstOrNull { it.id == q.stepId }?.params?.get(q.key) ?: ""
                        OutlinedTextField(
                            value = answers[akey(i, q)] ?: init,
                            onValueChange = { answers[akey(i, q)] = it },
                            label = { Text(q.text) },
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                list.forEachIndexed { i, s ->
                    var steps = s.steps
                    s.questions.forEach { q ->
                        val ans = answers[akey(i, q)]
                        if (ans != null) {
                            steps = steps.map { st -> if (st.id == q.stepId) st.copy(params = st.params + (q.key to ans)) else st }
                        }
                    }
                    Store.add(s.copy(steps = steps))
                }
                onDone(true)
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = { onDone(false) }) { Text("Cancel") } }
    )
}

@Composable
fun ShareChooser(input: String, nav: Nav, onClose: () -> Unit) {
    val flagged = Store.items.filter { it.share }
    val list = if (flagged.isEmpty()) Store.items.toList() else flagged
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Run a shortcut with this") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (flagged.isEmpty()) Text("No shortcut has Share Sheet turned on, so all are listed.", fontSize = 12.sp, color = Ios.gray)
                list.forEach { s ->
                    TextButton(onClick = { onClose(); nav.run(s, input) }) { Text(s.glyph + "  " + s.name) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

// ---------------- Gallery ----------------

@Composable
fun GalleryTab(nav: Nav) {
    var preview by remember { mutableStateOf<GalleryItem?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item { Text("Gallery", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)) }
        for ((cat, list) in Gallery.categories) {
            item(key = "cat-$cat") {
                Text(cat, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
            }
            items(list.chunked(2), key = { row -> cat + row[0].shortcut.name }) { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { g ->
                        Column(
                            Modifier.weight(1f).height(110.dp).clip(RoundedCornerShape(16.dp)).background(tileColor(g.shortcut.color))
                                .clickable { preview = g }.padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(g.shortcut.glyph, fontSize = 26.sp)
                            Text(g.shortcut.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
    val g = preview
    if (g != null) {
        AlertDialog(
            onDismissRequest = { preview = null },
            title = { Text(g.shortcut.glyph + "  " + g.shortcut.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(g.desc, color = Ios.gray)
                    Spacer(Modifier.height(8.dp))
                    g.shortcut.steps.filter { it.type !in setOf("else", "endif", "endrepeat", "endmenu") }.forEach { st ->
                        Text("• " + (Catalog.byType[st.type]?.title ?: st.type), fontSize = 14.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    Store.add(g.shortcut.fresh())
                    nav.toastText = "Added to My Shortcuts"
                    preview = null
                }) { Text("Add Shortcut") }
            },
            dismissButton = { TextButton(onClick = { preview = null }) { Text("Close") } }
        )
    }
}

// ---------------- Automation ----------------

@Composable
fun AutomationTab(nav: Nav) {
    val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.weight(1f))
                LinkText("＋") {
                    if (Store.items.isEmpty()) nav.toastText = "Create a shortcut first" else nav.push(Route.AutoEdit(null))
                }
            }
            Text("Automation", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        }
        if (Store.automations.isEmpty()) {
            item {
                Text(
                    "Automations run a shortcut when something happens: a time of day, charger connected, Wi-Fi, Bluetooth, battery level and more.\n\nTap ＋ to create one.",
                    color = Ios.gray, modifier = Modifier.padding(8.dp)
                )
            }
        }
        items(Store.automations.toList(), key = { it.id }) { a ->
            val sc = Store.get(a.shortcutId)
            val d = AutoCatalog.byType[a.type]
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { nav.push(Route.AutoEdit(a.id)) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlyphBox(d?.glyph ?: "⚙", Ios.blue, 40.dp, 10.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(d?.title ?: a.type, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(AutoCatalog.describe(a), fontSize = 13.sp, color = Ios.gray)
                    Text("Run: " + (sc?.name ?: "(deleted)") + if (a.askBefore) " · asks first" else " · runs immediately", fontSize = 13.sp, color = Ios.gray)
                }
                Switch(checked = a.enabled, onCheckedChange = { on ->
                    Store.updateAutomation(a.copy(enabled = on))
                    if (on) requestAutoPermissions(ctx, a.type)
                    AutomationService.refresh(ctx)
                })
            }
        }
    }
}

private fun requestAutoPermissions(ctx: Context, type: String) {
    val act = ctx.findActivity() ?: return
    if (type == "bluetooth" && Build.VERSION.SDK_INT >= 31) {
        act.requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
    }
}

@Composable
fun AutomationEditScreen(nav: Nav, id: String?) {
    val ctx = LocalContext.current
    val existing = id?.let { aid -> Store.automations.firstOrNull { it.id == aid } }
    var type by remember { mutableStateOf(existing?.type ?: "time") }
    var params by remember { mutableStateOf(existing?.params ?: emptyMap<String, String>()) }
    var shortcutId by remember { mutableStateOf(existing?.shortcutId ?: (Store.items.firstOrNull()?.id ?: "")) }
    var askBefore by remember { mutableStateOf(existing?.askBefore ?: true) }
    var shortcutMenu by remember { mutableStateOf(false) }
    val def = AutoCatalog.byType[type]

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopRow(if (existing == null) "New Automation" else "Edit Automation", nav, "Cancel") {
            LinkText("Save") {
                if (shortcutId.isBlank()) {
                    nav.toastText = "Choose a shortcut"
                } else {
                    val full = HashMap<String, String>()
                    def?.params?.forEach { p -> full[p.key] = params[p.key] ?: p.def }
                    val a = Automation(
                        id = existing?.id ?: newUuid(), shortcutId = shortcutId, type = type,
                        params = full, enabled = existing?.enabled ?: true, askBefore = askBefore
                    )
                    if (existing == null) Store.addAutomation(a) else Store.updateAutomation(a)
                    requestAutoPermissions(ctx, type)
                    AutomationService.refresh(ctx)
                    nav.pop()
                }
            }
        }
        Column(Modifier.padding(16.dp)) {
            SectionLabel("When")
            Group {
                AutoCatalog.all.forEachIndexed { i, d ->
                    if (i > 0) HorizontalDivider(Modifier.padding(start = 56.dp))
                    Row(
                        Modifier.fillMaxWidth().clickable { type = d.type; params = emptyMap() }.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GlyphBox(d.glyph, Ios.blue, 30.dp, 8.dp)
                        Text(d.title, fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
                        if (d.type == type) Text("✓", color = Ios.blue, fontSize = 18.sp)
                    }
                }
            }
            if (def != null && def.params.isNotEmpty()) {
                SectionLabel("Options")
                Group(Modifier.padding(12.dp)) {
                    def.params.forEach { p ->
                        val value = params[p.key] ?: p.def
                        val opts = p.options
                        if (opts != null) {
                            var open by remember(type, p.key) { mutableStateOf(false) }
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(p.label, modifier = Modifier.weight(1f))
                                Box {
                                    Text(
                                        "$value ⌄", color = Ios.blue,
                                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable { open = true }.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                        opts.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { params = params + (p.key to o); open = false }) }
                                    }
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = value, onValueChange = { params = params + (p.key to it) },
                                label = { Text(p.label) }, singleLine = true,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }
            SectionLabel("Do")
            Group {
                Row(
                    Modifier.fillMaxWidth().clickable { shortcutMenu = true }.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Run shortcut", fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Box {
                        Text((Store.get(shortcutId)?.name ?: "Choose") + " ⌄", color = Ios.blue, fontSize = 17.sp)
                        DropdownMenu(expanded = shortcutMenu, onDismissRequest = { shortcutMenu = false }) {
                            Store.items.forEach { s ->
                                DropdownMenuItem(text = { Text(s.glyph + "  " + s.name) }, onClick = { shortcutId = s.id; shortcutMenu = false })
                            }
                        }
                    }
                }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                SwitchRow("Ask Before Running", askBefore) { askBefore = it }
            }
            Text(
                if (askBefore) "You'll get a notification; tap it to run the shortcut."
                else "Runs in the background. Questions use their default answer and results appear as notifications.",
                fontSize = 12.sp, color = Ios.gray, modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
            if (existing != null) {
                Spacer(Modifier.height(16.dp))
                Group {
                    ActionRow("Delete Automation", Ios.red) {
                        AutomationScheduler.cancel(ctx, existing)
                        Store.deleteAutomation(existing.id)
                        AutomationService.refresh(ctx)
                        nav.pop()
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ---------------- Settings ----------------

@Composable
fun SettingsScreen(nav: Nav) {
    val ctx = LocalContext.current
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(Store.exportAll()) }
                nav.toastText = "Backup saved"
            } catch (e: Exception) { nav.toastText = "Backup failed" }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                nav.importText(text)
            } catch (e: Exception) { nav.toastText = "Could not read that file" }
        }
    }
    fun open(i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { nav.toastText = "Not available on this device" }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopRow("Settings", nav, "‹ Done")
        Column(Modifier.padding(16.dp)) {
            SectionLabel("Library")
            Group {
                ActionRow("Layout: " + Store.layout + "  (tap to switch)") { Store.changeLayout(if (Store.layout == "Grid") "List" else "Grid") }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                for (so in listOf("Name", "Last Modified", "Date Created", "Custom Order")) {
                    ActionRow((if (Store.sort == so) "✓ " else "    ") + "Sort by " + so, if (Store.sort == so) Ios.blue else Ios.gray) { Store.changeSort(so) }
                }
            }
            SectionLabel("Backup")
            Group {
                ActionRow("Export all shortcuts") { saver.launch("shortcuts-backup.json") }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Import from file") { picker.launch(arrayOf("*/*")) }
            }
            SectionLabel("Permissions for automations")
            Group {
                ActionRow("Notifications") {
                    open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
                }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Exact alarms (Time of Day accuracy)") {
                    if (Build.VERSION.SDK_INT >= 31) {
                        open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                    } else nav.toastText = "Not needed on this Android version"
                }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Battery optimization (keep automations alive)") {
                    open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
                HorizontalDivider(Modifier.padding(start = 16.dp))
                ActionRow("Do Not Disturb access (ringer / volume actions)") {
                    open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            }
            SectionLabel("URL scheme")
            Text(
                "shortcuts://run-shortcut?name=NAME&input=TEXT\nshortcuts://open-shortcut?name=NAME\nshortcuts://create-shortcut?name=NAME\nshortcuts://gallery",
                fontSize = 13.sp, color = Ios.gray, modifier = Modifier.padding(start = 16.dp, end = 16.dp)
            )
            SectionLabel("About")
            Text("Shortcuts for Android · v0.2", fontSize = 15.sp, modifier = Modifier.padding(start = 16.dp))
            Spacer(Modifier.height(24.dp))
        }
    }
}
